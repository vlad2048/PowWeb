﻿using PowBasics.Geom;
using PowWeb._Internal.ChromeDevApi.DDomSnapshot.Enums;

namespace PowWeb.Structs.SnapshotStructs;

public record SnapshotNode(
	int Index,
	int ParentIndex,
	DomNodeType NodeType,
	DomShadowRootType? ShadowRootType,
	string Name,
	string Value,
	int? BackendNodeId,
	SnapshotAttr[] Attrs,
	string? TextValue,
	string? InputValue,
	bool? InputChecked,
	bool? OptionSelected,
	int? ContentDocumentIndex,
	string? PseudoType,
	string? PseudoIdentifier,
	bool? IsClickable,
	string? CurrentSourceURL,
	string? OriginURL,

	string[]? Styles,
	R? Bounds,
	string? Text,
	bool? StackingContexts,
	int? PaintOrders,
	R? OffsetRects,
	R? ScrollRects,
	R? ClientRects,
	string? BlendedBackgroundColors,
	double? TextColorOpacities
);



public static class SnapshotNodeExt
{
	public static string? GetAttr(this SnapshotNode node, string attrName) =>
		node.Attrs.FirstOrDefault(e => e.Name == attrName)?.Value;
}