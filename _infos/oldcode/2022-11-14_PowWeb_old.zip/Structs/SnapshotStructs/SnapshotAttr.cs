﻿namespace PowWeb.Structs.SnapshotStructs;

public record SnapshotAttr(string Name, string? Value)
{
	public override string ToString() => $"{Name}='{Value}'";
}