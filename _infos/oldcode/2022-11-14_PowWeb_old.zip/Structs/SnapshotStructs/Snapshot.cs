﻿namespace PowWeb.Structs.SnapshotStructs;

public record Snapshot(
	SnapshotDoc[] Docs,
	string Screenshot
);