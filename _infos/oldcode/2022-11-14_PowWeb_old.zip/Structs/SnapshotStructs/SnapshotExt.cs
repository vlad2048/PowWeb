﻿namespace PowWeb.Structs.SnapshotStructs;

public static class SnapshotExt
{
	public static Bitmap GetScreenshotBmp(this string screenshotStr)
	{
		var bytes = Convert.FromBase64String(screenshotStr);
		/*using */var ms = new MemoryStream(bytes);
		var img = Image.FromStream(ms);
		if (img is not Bitmap bmp) throw new InvalidOperationException();
		return bmp;
	}
}