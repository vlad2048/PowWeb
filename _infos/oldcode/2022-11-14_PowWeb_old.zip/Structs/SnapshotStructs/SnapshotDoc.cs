﻿namespace PowWeb.Structs.SnapshotStructs;

public record SnapshotDoc(
	string BaseUrl,
	string DocumentUrl,
	string Title,
	TNod<SnapshotNode> Root
);