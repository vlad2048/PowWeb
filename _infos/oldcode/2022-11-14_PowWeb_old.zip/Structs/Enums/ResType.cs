﻿using PuppeteerSharp;

namespace PowWeb.Structs.Enums;

public enum ResType
{
	Unknown = -1,
	Document = 0,
	Stylesheet = 1,
	Image = 2,
	Media = 3,
	Font = 4,
	Script = 5,
	TextTrack = 6,
	XHR = 7,
	Fetch = 8,
	EventSource = 9,
	WebSocket = 10,
	Manifest = 11,
	SignedExchange = 12,
	Ping = 13,
	CSPViolationReport = 14,
	Preflight = 15,
	Other = 16
}

static class ResTypeUtils
{
	public static ResType ResourceType2ResType(_Internal.ChromeDevApi.DNetwork.Enums.ResourceType t) =>
		(ResType)(int)t;

	public static ResType ResourceType2ResType(PuppeteerSharp.ResourceType t) => t switch
	{
		ResourceType.Unknown => ResType.Unknown,
		ResourceType.Document => ResType.Document,
		ResourceType.StyleSheet => ResType.Stylesheet,
		ResourceType.Image => ResType.Image,
		ResourceType.Media => ResType.Media,
		ResourceType.Font => ResType.Font,
		ResourceType.Script => ResType.Script,
		ResourceType.TextTrack => ResType.TextTrack,
		ResourceType.Xhr => ResType.XHR,
		ResourceType.Fetch => ResType.Fetch,
		ResourceType.EventSource => ResType.EventSource,
		ResourceType.WebSocket => ResType.WebSocket,
		ResourceType.Manifest => ResType.Other,
		ResourceType.Ping => ResType.Ping,
		ResourceType.Img => ResType.Image,
		ResourceType.Other => ResType.Other,
		_ => throw new ArgumentException()
	};
}