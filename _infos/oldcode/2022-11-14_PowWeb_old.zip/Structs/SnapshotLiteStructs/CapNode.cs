﻿using PowBasics.Geom;
using PowWeb._Internal.ChromeDevApi.DDomSnapshot.Enums;

namespace PowWeb.Structs.SnapshotLiteStructs;

public record CapNode(
	int Index,
	DomNodeType NodeType,
	string Name,
	string Text,
	CapAttr[] Attrs,
	R Bounds,
	bool? IsClickable
);