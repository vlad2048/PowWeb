﻿namespace PowWeb.Structs.SnapshotLiteStructs;

public record CapAttr(
	string Key,
	string? Val
);