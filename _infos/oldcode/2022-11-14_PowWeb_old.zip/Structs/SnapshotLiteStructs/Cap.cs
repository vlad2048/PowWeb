﻿namespace PowWeb.Structs.SnapshotLiteStructs;

public record Cap(
	string Url,
	string Screenshot,
	TNod<CapNode> Root
	//TNod<CapNode>[] OtherRoots
);