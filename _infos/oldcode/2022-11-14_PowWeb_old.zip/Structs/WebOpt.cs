﻿using PowBasics.Geom;
using PowWeb._Internal.ActionTracking;

namespace PowWeb.Structs;

public enum AdBlockMode
{
	Disabled,
	Enabled,
	EnabledCloseTabOnStartup
}

public class WebOpt
{
	/// <summary>
	/// Defines how we want to open the browser
	/// <para/>
	/// Default is OpenMode.ConnectOrCreate
	/// </summary>
	public OpenMode OpenMode { get; set; } = OpenMode.ConnectOrCreate;

	/// <summary>
	/// Specify where to store: downloaded chrome, user profiles and extensions.
	/// <para/>
	/// Default is C:\ProgramData\PowWeb\
	/// </summary>
	public string? StorageFolder { get; set; }

	/// <summary>
	/// Path to a Chromium or Chrome executable to run instead of bundled Chromium
	/// </summary>
	public string? ChromeExe { get; set; } = @"C:\Program Files\Google\Chrome\Application\chrome.exe";

	/// <summary>
	/// User profile to use (stored in the [StorageFolder]\Profiles)
	/// <para/>
	/// Default is magic
	/// </summary>
	public string Profile { get; set; } = "magic";

	/// <summary>
	/// If true, it will delete the user profile folder before starting
	/// <para/>
	/// Default is false
	/// </summary>
	public bool DeleteProfile { get; set; }

	/// <summary>
	/// Location of the browser window on the desktop when not running in headless mode
	/// </summary>
	public Pt WinLoc { get; set; } = ActionTrackingConsts.DefaultPuppeteerWinPos;
	
	/// <summary>
	/// Run in headless mode
	/// <para/>
	/// Default is false
	/// </summary>
	public bool Headless { get; set; }

	/// <summary>
	/// Open DevTools
	/// <para/>
	/// Default is false
	/// </summary>
	public bool DevTools { get; set; }

	/// <summary>
	/// Install and use the AdBlockPlus extension
	/// <para/>
	/// Default is EnabledCloseTabOnStartup
	/// </summary>
	public AdBlockMode AdBlockMode { get; set; } = AdBlockMode.EnabledCloseTabOnStartup;

	/// <summary>
	/// Debug port
	/// <para/>
	/// Default is 2122
	/// </summary>
	public int DebugPort { get; set; } = 2122;

	/// <summary>
	/// Log initialization sequence to the console
	/// <para/>
	/// Default is true
	/// </summary>
	public bool LogInit { get; set; } = true;

	/// <summary>
	/// When LogInit is set, each log string will be output using this function. If this function is null, it will be output to the console using Console.Write/Console.WriteLine
	/// <para/>
	/// Default is null
	/// </summary>
	public Action<string>? LogInitWrite { get; set; } = null;
	public Action<string>? LogInitWriteLine { get; set; } = null;

	internal static WebOpt Build(Action<WebOpt>? action)
	{
		var opt = new WebOpt();
		action?.Invoke(opt);
		return opt;
	}
}