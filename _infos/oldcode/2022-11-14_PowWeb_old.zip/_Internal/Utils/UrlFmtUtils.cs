﻿namespace PowWeb._Internal.Utils;

static class UrlFmtUtils
{
	public static string FmtUrlSimple(this string url)
	{
		var res = Path.GetDirectoryName(url) ?? string.Empty;
		return (res == string.Empty) switch {
			false => res,
			true => url
		};
	}
}