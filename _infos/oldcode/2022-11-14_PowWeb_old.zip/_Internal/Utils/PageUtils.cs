﻿using PowWeb.Functionality.Web_Capture_Utils;
using PuppeteerSharp;

namespace PowWeb._Internal.Utils;

static class PageUtils
{
	private static readonly string[] ignoreUrls =
	{
		"adblockplus",
		"chrome-extension",
	};

	public static Page GetPageOnStartup(Browser browser)
	{
		var pages = browser.PagesAsync().Result;
		var validPages = pages.Where(e => !ignoreUrls.Any(f => e.Url.Contains(f))).ToArray();
		var invalidPages = pages.Where(e => !validPages.Contains(e)).ToArray();
		invalidPages.ClosePages();
		if (validPages.Length == 0) throw new ArgumentException("No valid page found on startup");

		var startupPage = validPages[0];
		validPages.Skip(1).ClosePages();
		return startupPage;
	}

	public static void CloseUnwantedTabsWhenAccessingPage(Browser browser, Page page, string currentUrl)
	{
		var pages = browser.PagesAsync().Result;
		//var matchingPage = pages.FirstOrDefault(e => DoUrlsMatch(e.Url, currentUrl));
		var matchingPage = pages.FirstOrDefault(e => e == page);
		if (matchingPage == null) throw new ArgumentException("Cannot find our current page");

		var otherPages = pages.Where(e => e != matchingPage).ToArray();
		otherPages.ClosePages();
	}

	private static bool DoUrlsMatch(string a, string b)
	{
		var sa = UrlUtils.PreProcess(UrlUtils.RemoveUrlParams(a));
		var sb = UrlUtils.PreProcess(UrlUtils.RemoveUrlParams(b));
		return string.Compare(sa, sb, StringComparison.OrdinalIgnoreCase) == 0;
	}

	private static void ClosePages(this IEnumerable<Page> pages)
	{
		foreach (var page in pages)
			page.CloseAsync().Wait();
	}
}


/*
using Newtonsoft.Json.Linq;
using PuppeteerSharp;

namespace PowWeb.Utils;

static class PageUtils
{
	public static Page GetVisiblePage(this Browser browser)
	{
		var pages = browser.PagesAsync().Result;
		return pages[0];

		//var pages = browser.PagesAsync().Result;
		//if (pages.Length == 0)
		//	throw new InvalidOperationException($"[vlad] Could not find pages in the browser");
		//var visPage = pages.FirstOrDefault(e => e.IsVisible());
		//if (visPage != null)
		//	return visPage;
		//return pages.First();
	}

	private static bool IsVisible(this Page page)
	{
		var stateObj = page.EvaluateExpressionAsync("document.visibilityState").Result;
		if (stateObj is not JValue stateVal) return false;
		if (stateVal.Value is not string valStr) return false;
		if (valStr != "visible") return false;
		return true;
	}
}
*/
