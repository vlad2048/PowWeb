﻿using PuppeteerSharp;

namespace PowWeb._Internal.Utils;

static class BrowserUtils
{
	public static TNod<Frame> GetFrameTree(Page page)
	{
		var root = Nod.Make(page.MainFrame);

		void AddChildren(TNod<Frame> nod)
		{
			foreach (var childFrame in nod.V.ChildFrames) {
				var childNod = Nod.Make(childFrame);
				nod.AddChild(childNod);
				AddChildren(childNod);
			}
		}

		AddChildren(root);

		var actCnt = page.Frames.Length;
		var expCnt = root.Count();
		if (expCnt != actCnt) {
			// this can happen but it should only be temporary (short)
			Console.WriteLine($"WRONG FRAME NUMBER (tree:{expCnt}   list:{actCnt})");
		}

		return root;
	}
}