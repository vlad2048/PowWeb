﻿namespace PowWeb._Internal;

static class Consts
{
	public const string InitialUrl = "about:blank";

	public const string FolderRoot = "PowWeb";
	public const string FolderDownload = "Download";
	public const string FolderDownloadCache = "DownloadCache";
	public const string FolderProfiles = "Profiles";
	public const string FolderExtensions = "Extensions";
	public const string SubFolderAdblockPlus = "AdblockPlus";
	public const string AdblockPlusZipFile = @"_Internal\Data\AdblockPlus.zip";

	public static readonly TimeSpan AdblockInitialTabCloseInitialDelay = TimeSpan.FromMilliseconds(3000);
	public static readonly TimeSpan AdblockInitialTabCloseDelayBeforeRuns = TimeSpan.FromMilliseconds(1000);
	public const int AdblockInitialTabCloseRetries = 3;

	public const string BodyName = "BODY";
}