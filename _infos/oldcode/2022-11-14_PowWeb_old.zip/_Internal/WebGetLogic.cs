﻿using PowWeb._Internal.ExtWebOpt;
using PowWeb._Internal.Logic;
using PowWeb.Structs;
using PuppeteerSharp;

namespace PowWeb._Internal;

static class WebGetLogic
{
	public static Web Get(Action<WebOpt>? optFun = null) => WebOpt.Build(optFun).OpenMode switch {
		OpenMode.Create => Create(optFun),
		OpenMode.Connect => Connect(optFun),
		OpenMode.ConnectOrCreate => ProcExt.IsUp() switch {
			true => Connect(optFun),
			false => Create(optFun)
		},
		_ => throw new ArgumentException()
	};



	private static Web Create(Action<WebOpt>? optFun)
	{
		var opt = WebOpt.Build(optFun);
		opt.KillIfUp();
		using var fetcher = new BrowserFetcher(new BrowserFetcherOptions {
			Path = opt.DownloadFolder(),
			CustomFileDownload = (srcUrl, dstFile) => {
				opt.DownloadChromiumIfNotCached(srcUrl, dstFile);
				return Task.CompletedTask;
			}
		});

		opt.LogInline("Download ... ");
		fetcher.DownloadAsync().Wait();
		opt.Log("done");

		opt.EmptyProfileIfNeeded();

		var args = new List<string>
		{
			$@"--user-data-dir=""{opt.ProfileFolder()}""",
			$@"--disable-web-security" ,
			$@"--disable-features=IsolateOrigins,site-per-process",
			$@"--window-position={opt.WinLoc.X},{opt.WinLoc.Y}",
			$@"--remote-debugging-port={opt.DebugPort}",
			$@"--disable-site-isolation-trials",	// otherwise Puppeteer cannot listen to requests made in iFrames when not running in headless mode
		};

		if (opt.AdBlockMode != AdBlockMode.Disabled) {
			args.Add($@"--disable-extensions-except=""{opt.GetAdblockPlusExtensionFolder()}""");
			args.Add($@"--load-extension=""{opt.GetAdblockPlusExtensionFolder()}""");
		}

		opt.LogInline("Launch ... ");
		var browser = Puppeteer.LaunchAsync(
			new LaunchOptions {
				Headless = opt.Headless,
				Devtools = opt.DevTools,
				ExecutablePath = opt.ChromeExe,
				Args = args.ToArray(),
			}
		).Result;
		opt.Log("done");

		//TargetLogger.Log(browser, opt, false);
		//AdblockInitialTabClosingLogic.Close(browser, opt);

		if (opt.AdBlockMode == AdBlockMode.EnabledCloseTabOnStartup)
		{
			using var adblockWaiter = new AdblockPlusWaiter(browser, opt);
			adblockWaiter.Wait();
		}

		return new Web(browser, opt);
	}

	private static Web Connect(Action<WebOpt>? optFun)
	{
		if (!ProcExt.IsUp())
			throw new InvalidOperationException("Could not find an instance of Puppeteer to connect to");
		var opt = WebOpt.Build(optFun);

		opt.LogInline("Connect ... ");
		var browser = Puppeteer.ConnectAsync(
			new ConnectOptions {
				BrowserURL = $"ws://127.0.0.1:{opt.DebugPort}",
			}
		).Result;
		opt.Log("done");

		opt.BringToTop();

		return new Web(browser, opt);
	}
}