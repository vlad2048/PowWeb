﻿using PowWeb.Structs;

namespace PowWeb._Internal.ExtWebOpt;

static class LogExt
{
	public static void LogInline(this WebOpt opt, string str)
	{
		if (!opt.LogInit) return;
		if (opt.LogInitWrite != null)
			opt.LogInitWrite(str);
		else
			Console.Write(str);
	}

	public static void Log(this WebOpt opt, string str)
	{
		//str = $"[{DateTime.Now:HH:mm:ss.fff}] {str}";
		if (!opt.LogInit) return;
		if (opt.LogInitWriteLine != null)
			opt.LogInitWriteLine(str);
		else
			Console.WriteLine(str);
	}
}