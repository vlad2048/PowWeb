﻿using System.Reactive.Disposables;
using System.Reactive.Subjects;
using PowBasics.Geom;
using PowBasics.WinForms.Extensions;
using PowRxVar;
using PowRxVar.Utils;
using PowWeb._Internal.ActionTracking.Logic;
using PowWeb._Internal.ActionTracking.Structs;

namespace PowWeb._Internal.ActionTracking;

partial class ActionWin : Form
{
	public ISubject<ITrackEvent> TrackEvtSig { get; }
	public ActionWin()
	{
		InitializeComponent();

		var d = new Disp().D(this);

		(TrackEvtSig, var trackEvtObs) = RxEventMaker.Make<ITrackEvent>().D(d);
		var state = new State(trackEvtObs).D(d);

		state.WinVisible.Subscribe(visible =>
		{
			if (visible)
				Show();
			else
				Hide();
		}).D(d);

		state.WinPos.Subscribe(pos =>
		{
			Location = pos.ToPoint();
		}).D(d);

		state.WhenRedrawNeeded.Subscribe(_ =>
		{
			Update();
			//Invalidate();
		}).D(d);

		this.Events().Paint.Subscribe(e =>
		{
			var gfx = e.Graphics;
			var r = new R(Pt.Empty, new Sz(ClientSize.Width, ClientSize.Height));
			DrawingLogic.Draw(gfx, r, state.DrawState.V);
		}).D(d);
	}
}
