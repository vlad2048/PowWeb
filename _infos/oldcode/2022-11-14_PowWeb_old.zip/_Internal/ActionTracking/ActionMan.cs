﻿using System.Reactive.Disposables;
using PowRxVar;
using PowWeb._Internal.ActionTracking.Structs;

namespace PowWeb._Internal.ActionTracking;

class ActionMan : IDisposable
{
	private readonly Disp d = new();
	public void Dispose() => d.Dispose();

	private readonly ActionWin win;

	public void SendCmd(ITrackEvent evt) => win.TrackEvtSig.OnNext(evt);

	public ActionMan()
	{
		win = new ActionWin().D(d);
	}
}