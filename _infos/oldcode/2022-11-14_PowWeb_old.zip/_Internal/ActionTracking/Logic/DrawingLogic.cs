﻿using PowBasics.Geom;
using PowWeb._Internal.ActionTracking.Structs;
using PowWeb._Internal.ActionTracking.Utils;

namespace PowWeb._Internal.ActionTracking.Logic;

static class DrawingLogic
{
	private static readonly Brush backBrush = new SolidBrush(Color.LimeGreen);

	public static void Draw(Graphics gfx, R r, IDrawState state)
	{
		gfx.FillR(backBrush, r);

		switch (state)
		{
			case MouseDrawState:
			{
				gfx.DrawBmp(ActionTrackingConsts.MouseBmp);
				break;
			}

			case MouseClickDrawState:
			{
				gfx.DrawBmp(ActionTrackingConsts.MouseClickBmp);
				break;
			}
		}
	}
}