﻿using System.Reactive;
using System.Reactive.Concurrency;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using PowBasics.Geom;
using PowMaybe;
using PowRxVar;
using PowWeb._Internal.ActionTracking.Structs;

namespace PowWeb._Internal.ActionTracking.Logic;

class State : IDisposable
{
	private readonly Disp d = new();
	public void Dispose() => d.Dispose();

	public IRoVar<IDrawState> DrawState { get; }
	public IRoVar<bool> WinVisible { get; }
	public IRoVar<Pt> WinPos { get; }
	public IObservable<Unit> WhenRedrawNeeded { get; }

	public State(IObservable<ITrackEvent> evtObs)
	{
		var drawState = Var.Make<IDrawState>(new NoneDrawState()).D(d);
		DrawState = drawState;

		WinVisible = DrawState.SelectVar(e => e is IPosDrawState);
		WinPos = Var.Make(
			Pt.Empty,
			DrawState.OfType<IPosDrawState>().Select(e => e.WinPos)
		).D(d);

		WhenRedrawNeeded = DrawState
			.Where(_ => WinVisible.V)
			.ToUnit();

		evtObs
			//.ObserveOn(NewThreadScheduler.Default)
			.SubscribeWithDisp((evt, evtD) =>
		{
			switch (evt)
			{
				case MouseClickTrackEvent e:
				{
					async Task DoClick(CancellationToken ct)
					{
						try
						{
							var winPos = ConvertCoords(e.Pos);

							drawState.V = new MouseDrawState(winPos);

							await Task.Delay(evt.Delay, ct);

							drawState.V = new MouseClickDrawState(winPos);

							await Task.Delay(ActionTrackingConsts.ClickShowDuration, ct);

							drawState.V = new MouseDrawState(winPos);

							await Task.Delay(ActionTrackingConsts.ClickStayAfterDuration, ct);
						}
						catch (OperationCanceledException) { }
						finally
						{
							drawState.V = new NoneDrawState();
						}
					}

					var cancelSource = new CancellationTokenSource();
					Disposable.Create(() => cancelSource.Cancel()).D(evtD);

					DoClick(cancelSource.Token);
					break;
				}
			}
		}).D(d);
	}

	private static Pt ConvertCoords(Pt p) => p
		- ActionTrackingConsts.MouseBmpHalfSize
		+ ActionTrackingConsts.DefaultPuppeteerWinPos
		+ ActionTrackingConsts.PuppeteerWinOffset;
}