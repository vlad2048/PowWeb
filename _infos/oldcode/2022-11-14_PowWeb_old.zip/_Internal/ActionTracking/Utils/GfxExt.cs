﻿using PowBasics.Geom;

namespace PowWeb._Internal.ActionTracking.Utils;

static class GfxExtensions
{
	public static void FillR(this Graphics gfx, Brush brush, R r) =>
		gfx.FillRectangle(brush, r.X, r.Y, r.Width, r.Height);

	public static void DrawR(this Graphics gfx, Pen pen, R r) =>
		gfx.DrawRectangle(pen, r.X, r.Y, r.Width, r.Height);

	public static void DrawBmp(this Graphics gfx, Bitmap bmp) =>
		gfx.DrawImage(bmp, 0, 0);
}