﻿using PowBasics.Geom;

namespace PowWeb._Internal.ActionTracking.Structs;

interface ITrackEvent
{
	TimeSpan Delay { get; }
}

record MouseClickTrackEvent(Pt Pos, TimeSpan Delay) : ITrackEvent;