﻿using PowBasics.Geom;

namespace PowWeb._Internal.ActionTracking.Structs;

interface IDrawState { }

interface IPosDrawState : IDrawState
{
	Pt WinPos { get; }
}

record NoneDrawState : IDrawState;

record MouseDrawState(Pt WinPos) : IPosDrawState;

record MouseClickDrawState(Pt WinPos) : IPosDrawState;
