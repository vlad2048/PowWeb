﻿using PowBasics.Geom;

namespace PowWeb._Internal.ActionTracking;

static class ActionTrackingConsts
{
	public static readonly Bitmap MouseBmp = ActionTrackingResources.mouse_cursor;
	public static readonly Bitmap MouseClickBmp = ActionTrackingResources.mouse_cursor_click;
	public static readonly Pt MouseBmpHalfSize = new(MouseBmp.Width / 2, MouseBmp.Height / 2);

	public static readonly TimeSpan ClickShowDuration = TimeSpan.FromMilliseconds(400);
	public static readonly TimeSpan ClickStayAfterDuration = TimeSpan.FromMilliseconds(10000);

	public static readonly Pt DefaultPuppeteerWinPos = new(-940, 0);
	public static readonly Pt PuppeteerWinOffset = new(8, 130);
}