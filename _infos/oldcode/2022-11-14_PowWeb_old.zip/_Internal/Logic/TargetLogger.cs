﻿using PowWeb._Internal.ExtWebOpt;
using PowWeb._Internal.Utils;
using PowWeb.Structs;
using PuppeteerSharp;

namespace PowWeb._Internal.Logic;

static class TargetLogger
{
	public static void Log(Browser browser, WebOpt opt, bool logPages)
	{
		void LogState(string title)
		{
			var targets = browser.Targets();
			opt.Log($"  [{title}] targets:{targets.Length}");
			var pageMap = new Dictionary<Page, int>();
			var pageCnt = 0;
			for (var i = 0; i < targets.Length; i++)
			{
				var target = targets[i];
				var url = target.Url;
				var pageStr = string.Empty;
				if (logPages)
				{
					var page = target.PageAsync().Result;
					pageStr = " page:_";
					if (page != null)
					{
						if (!pageMap.TryGetValue(page, out var pageIdx))
						{
							pageIdx = pageMap[page] = pageCnt++;
						}
						pageStr = $" page:{pageIdx}";
					}
				}

				var typeStr = $"{target.Type}".PadRight(20);
				opt.Log($"    [{i}]{pageStr}: {typeStr}'{url.FmtUrlSimple()}'");
			}
			opt.Log("");
		}

		LogState("Initial");
		browser.TargetCreated += (_, _) => LogState("TargetCreated");
		browser.TargetDestroyed += (_, _) => LogState("TargetDestroyed");
		browser.TargetChanged += (_, _) => LogState("TargetChanged");
	}
}