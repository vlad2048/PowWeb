﻿using PowBasics.Geom;

namespace PowWeb._Internal.Logic.SnapshotConversion.Structs;

record LayRec(
	int Index,
	string[] Styles,
	R Bounds,
	string Text,
	bool StackingContexts,
	int? PaintOrders,
	R? OffsetRects,
	R? ScrollRects,
	R? ClientRects,
	string? BlendedBackgroundColors,
	double? TextColorOpacities
);