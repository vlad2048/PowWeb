﻿using PowWeb._Internal.ChromeDevApi.Utils.Extensions;
using PowWeb._Internal.Logic.SnapshotConversion.Maps;

namespace PowWeb._Internal.Logic.SnapshotConversion.Structs;

record AttrRec(string Name, string? Value)
{
	public static AttrRec[] Decode(int[][]? attributes, int nodeIdx, Ctx ctx)
	{
		if (attributes == null) return Array.Empty<AttrRec>();

		var flatArr = attributes[nodeIdx].SelectToArray(ctx.ReadStr);

		if (flatArr.Length % 2 != 0) throw new ArgumentException();
		return Enumerable.Range(0, flatArr.Length / 2).SelectToArray(i => new AttrRec(flatArr[i * 2 + 0], flatArr[i * 2 + 1]));
	}
}