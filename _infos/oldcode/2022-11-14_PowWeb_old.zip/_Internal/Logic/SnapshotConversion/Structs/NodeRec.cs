﻿using PowWeb._Internal.ChromeDevApi.DDomSnapshot.Enums;

namespace PowWeb._Internal.Logic.SnapshotConversion.Structs;

record NodeRec(
	int Index,
	int ParentIndex,
	DomNodeType NodeType,
	DomShadowRootType? ShadowRootType,
	string Name,
	string Value,
	int? BackendNodeId,
	AttrRec[] Attrs,
	string? TextValue,
	string? InputValue,
	bool? InputChecked,
	bool? OptionSelected,
	int? ContentDocumentIndex,
	string? PseudoType,
	string? PseudoIdentifier,
	bool? IsClickable,
	string? CurrentSourceURL,
	string? OriginURL
);