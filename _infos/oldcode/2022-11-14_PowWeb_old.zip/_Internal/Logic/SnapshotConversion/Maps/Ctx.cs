﻿using PowBasics.Geom;
using PowWeb._Internal.ChromeDevApi.DDomSnapshot.Enums;
using PowWeb._Internal.ChromeDevApi.Utils.Extensions;
using PowWeb._Internal.Logic.SnapshotConversion.Utils;

namespace PowWeb._Internal.Logic.SnapshotConversion.Maps;


class Ctx
{
	private readonly string[] strArr;

	public Ctx(string[] strArr)
	{
		this.strArr = strArr;
	}

	public string ReadStr(int strIdx) => (strIdx != -1) switch
	{
		true => strArr[strIdx],
		false => string.Empty
	};
	public string[] ReadStrArr(int[] strIndices) => strIndices.SelectToArray(e => strArr[e]);
}

static class CtxExt
{
	public static int? ReadIntOpt(this int[]? arr, int nodeIdx) => arr switch
	{
		not null => arr[nodeIdx],
		null => null
	};

	public static int ReadInt(this int[] arr, int nodeIdx) => arr[nodeIdx];

	public static DomShadowRootType? ReadStrAsShadowRootTypeOpt(this RareStringMap map, int nodeIdx) =>
		map.Get(nodeIdx).Parse(Enum.Parse<DomShadowRootType>);

	public static string ReadStr(this Ctx ctx, int[] strIndices, int nodeIdx) => ctx.ReadStr(strIndices[nodeIdx]);

	public static string? ReadStrOpt(this Ctx ctx, int[]? strIndices, int nodeIdx) => strIndices switch
	{
		not null => ctx.ReadStr(strIndices[nodeIdx]),
		null => null
	};

	public static R? ReadROpt(this double[][]? arr, int nodeIdx) => arr switch
	{
		not null => arr[nodeIdx].Length switch
		{
			4 => arr[nodeIdx].ToR(),
			_ => null
		},
		null => null
	};

	public static double? ReadDoubleOpt(this double[]? arr, int nodeIdx) => arr switch
	{
		not null => arr[nodeIdx],
		null => null
	};
}