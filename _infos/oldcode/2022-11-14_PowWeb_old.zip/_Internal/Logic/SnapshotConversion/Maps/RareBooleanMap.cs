﻿using PowWeb._Internal.ChromeDevApi.DDomSnapshot.Structs;

namespace PowWeb._Internal.Logic.SnapshotConversion.Maps;

class RareBooleanMap
{
	private readonly HashSet<int> set;

	public RareBooleanMap(RareBooleanData? data)
	{
		set = data switch {
			not null => data.Index.ToHashSet(),
			null => new HashSet<int>()
		};
	}

	public bool Get(int nodeIdx) => set.Contains(nodeIdx);
}