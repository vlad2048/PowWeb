﻿using PowWeb._Internal.ChromeDevApi.DDomSnapshot.Structs;

namespace PowWeb._Internal.Logic.SnapshotConversion.Maps;

class RareStringMap
{
	private readonly Dictionary<int, int> map;
	private readonly Ctx ctx;

	public RareStringMap(RareStringData? data, Ctx ctx)
	{
		this.ctx = ctx;
		map = data switch {
			not null => data.Index.Zip(data.Value)
				.Select(t => (nodeIdx: t.First, strIdx: t.Second))
				.ToDictionary(
					t => t.nodeIdx,
					t => t.strIdx
				),
			null => new Dictionary<int, int>(),
		};
	}

	public string? Get(int nodeIdx) => map.TryGetValue(nodeIdx, out var strIndex) switch {
		true => ctx.ReadStr(strIndex),
		false => null
	};
}