﻿using PowBasics.Geom;
using PowMaybe;
using PowTrees.Algorithms;
using PowWeb._Internal.ChromeDevApi.DDomSnapshot;
using PowWeb._Internal.ChromeDevApi.DDomSnapshot.Enums;
using PowWeb._Internal.ChromeDevApi.DDomSnapshot.Structs;
using PowWeb._Internal.ChromeDevApi.Utils.Extensions;
using PowWeb._Internal.Logic.SnapshotConversion.Logic;
using PowWeb._Internal.Logic.SnapshotConversion.Maps;
using PowWeb._Internal.Logic.SnapshotConversion.Structs;
using PowWeb._Internal.Logic.SnapshotConversion.Utils;
using PowWeb.Structs.SnapshotStructs;

namespace PowWeb._Internal.Logic.SnapshotConversion;


static class SnapshotConverter
{

	public static SnapshotDoc[] Convert(DomSnapshotApi.DomSnapshot_CaptureSnapshot_Ret snap)
		=>
			snap.Documents.SelectToArray(doc => ConvertDoc(doc, snap.Strings));

	private static SnapshotDoc ConvertDoc(DocumentSnapshot doc, string[] strArr)
	{
		CheckAssumptions(doc, strArr);
		var ctx = new Ctx(strArr);
		var nodes = NodeTreeSnapshotDecoder.Decode(doc.Nodes, ctx);
		var layMap = LayoutTreeSnapshotDecoder.Decode(doc.Layout, ctx)
			.ToDictionary(
				e => e.Index,
				e => e
			);

		var snapshotNodes = nodes.SelectToArray(n =>
		{
			layMap.TryGetValue(n.Index, out var lay);
			return new SnapshotNode(
				n.Index,
				n.ParentIndex,
				n.NodeType,
				n.ShadowRootType,
				n.Name,
				n.Value,
				n.BackendNodeId,
				n.Attrs.SelectToArray(e => new SnapshotAttr(e.Name, e.Value)),
				n.TextValue,
				n.InputValue,
				n.InputChecked,
				n.OptionSelected,
				n.ContentDocumentIndex,
				n.PseudoType,
				n.PseudoIdentifier,
				n.IsClickable,
				n.CurrentSourceURL,
				n.OriginURL,

				lay?.Styles,
				lay?.Bounds,
				lay?.Text,
				lay?.StackingContexts,
				lay?.PaintOrders,
				lay?.OffsetRects,
				lay?.ScrollRects,
				lay?.ClientRects,
				lay?.BlendedBackgroundColors,
				lay?.TextColorOpacities
			);
		});

		var root = MakeTreeFromNodes(snapshotNodes);
		return new SnapshotDoc(
			ctx.ReadStr(doc.BaseURL),
			ctx.ReadStr(doc.DocumentURL),
			ctx.ReadStr(doc.Title),
			root
		);
	}


	private static TNod<SnapshotNode> MakeTreeFromNodes(SnapshotNode[] nodes)
	{
		var map = nodes.ToDictionary(
			e => e.Index,
			e => Nod.Make(e)
		);

		var root = map.Values.Single(e => e.V.ParentIndex == -1);

		foreach (var (idx, nod) in map)
		{
			if (nod.V.ParentIndex == -1)
				continue;

			var parentNod = map[nod.V.ParentIndex];
			parentNod.AddChild(nod);
		}

		return root;
	}

	private static void CheckAssumptions(DocumentSnapshot doc, string[] strArr)
	{
		var nodes = doc.Nodes;
		var lays = doc.Layout;
		var strCnt = strArr.Length;

		void Check(bool cond)
		{
			if (!cond)
				throw new InvalidOperationException();
		}

		void CheckIsStrIndices(int[] arr) => Check(arr != null! && arr.All(e => e == -1 || (e >= 0 && e < strCnt)));

		Check(nodes.ParentIndex != null);
		Check(nodes.NodeType != null!);
		CheckIsStrIndices(nodes.NodeName);
		CheckIsStrIndices(nodes.NodeValue);
		Check(nodes.Attributes != null);
		foreach (var arr in nodes.Attributes!)
			CheckIsStrIndices(arr);
	}
}




/*
static class SnapshotConverter
{
	public static SnapshotDoc[] Convert(DomSnapshotApi.DomSnapshot_CaptureSnapshot_Ret snap)
		=>
			snap.Documents.SelectToArray(doc => ConvertDoc(doc, snap.Strings));


	public record DomAttrPrep(string Name, string? Value)
	{
		public override string ToString() => $"{Name}='{Value}'";
	}

	private record DomNodePrep(
		int Index,
		string Name,
		string? Value,
		DomAttrPrep[] Attrs,
		int? Type,
		int? BackendNodeId,
		bool IsClickable
	)
	{
		public string? Text { get; internal set; }
		public R? Bounds { get; internal set; }
		public R? ClientRect { get; internal set; }
		public R? OffsetRect { get; internal set; }
		public R? ScrollRect { get; internal set; }
	}


	private static SnapshotDoc ConvertDoc(DocumentSnapshot ret, string[] s)
	{
		var root = ret.Nodes.ConvRoot(s);
		root.SetLayoutInfo(ret.Layout, s);

		return new SnapshotDoc(
			s[ret.DocumentURL],
			ret.Title == -1 ? string.Empty : s[ret.Title],
			root.Map(e => new SnapshotNode(
				e.Index,
				e.Name,
				e.Value,
				e.Attrs.ConvAttrsToSnapshot(),
				e.Type,
				e.BackendNodeId,
				e.IsClickable,
				e.Text,
				e.Bounds,
				e.ClientRect,
				e.OffsetRect,
				e.ScrollRect
			))
		);
	}


	private static TNod<DomNodePrep> ConvRoot(this NodeTreeSnapshot ret, string[] s)
	{
		var map = new Dictionary<int, TNod<DomNodePrep>>();
		TNod<DomNodePrep>? root = null;
		var cnt = ret.NodeName.Length;
		var isClickableSet = ret.IsClickable == null ? new HashSet<int>() : ret.IsClickable.Index.ToHashSet();
		for (var i = 0; i < cnt; i++) {
			var parentIndex = ret.ParentIndex?[i];
			var nodeType = ret.NodeType?[i];
			var nodeName = ret.NodeName[i];
			var nodeValue = ret.NodeValue[i];
			var backendNodeId = ret.BackendNodeId?[i];
			var attrs = ret.Attributes == null ? Array.Empty<DomAttrPrep>() : ret.Attributes[i].ConvAttrs(s);
			var isClickable = isClickableSet.Contains(i);
			var nod = new DomNodePrep(
				i,
				s[nodeName],
				nodeValue == -1 ? null : s[nodeValue],
				attrs,
				nodeType,
				backendNodeId,
				isClickable
			);
			var tnod = Nod.Make(nod);
			map[i] = tnod;

			if (parentIndex == null || parentIndex == -1) {
				if (root != null) throw new ArgumentException("Root already found");
				root = tnod;
			} else {
				if (!map.TryGetValue(parentIndex.Value, out var parentNod)) throw new ArgumentException("Cannot find parent node");
				parentNod.AddChild(tnod);
			}
		}

		if (root == null) throw new ArgumentException("Could not find root");

		return root;
	}



	private static void SetLayoutInfo(this TNod<DomNodePrep> root, LayoutTreeSnapshot layout, string[] s)
	{
		var map = root.ToDictionary(e => e.V.Index, e => e.V);

		var indices = layout.NodeIndex;
		var cnt = indices.Length;

		void Set<T>(T[]? arr, Action<DomNodePrep, T> setFun)
		{
			if (arr == null) return;
			for (var i = 0; i < cnt; i++) {
				var index = indices[i];
				var val = arr[i];
				var node = map[index];
				setFun(node, val);
			}
		}

		Set(layout.Bounds, (node, e) => node.SetRect((n, r) => n.Bounds = r, e));
		Set(layout.ClientRects, (node, e) => node.SetRect((n, r) => n.ClientRect = r, e));
		Set(layout.ScrollRects, (node, e) => node.SetRect((n, r) => n.ScrollRect = r, e));
		Set(layout.OffsetRects, (node, e) => node.SetRect((n, r) => n.OffsetRect = r, e));
		Set(layout.Text, (node, e) => node.Text = e == -1 ? null : s[e]);
	}

	private static void SetRect(this DomNodePrep node, Action<DomNodePrep, R> setFun, double[] arr)
	{
		if (arr.Length == 0)
			return;
		var rect = arr.ToRect();
		setFun(node, rect);
	}

	private static R ToRect(this double[] arr) => new((int)arr[0], (int)arr[1], (int)arr[2], (int)arr[3]);


	private static DomAttrPrep[] ConvAttrs(this int[] ret, string[] s)
	{
		if (ret.Length % 2 != 0) throw new ArgumentException($"Wrong attrs length: {ret.Length}");
		var cnt = ret.Length / 2;
		var arr = new DomAttrPrep[cnt];
		for (var i = 0; i < cnt; i++) {
			var idxKey = ret[i * 2 + 0];
			var idxVal = ret[i * 2 + 1];
			var key = s[idxKey];
			var val = idxVal == -1 ? null : s[idxVal];
			arr[i] = new DomAttrPrep(key, val);
		}

		return arr;
	}

	private static SnapshotAttr[] ConvAttrsToSnapshot(this DomAttrPrep[] attrs) =>
		attrs.SelectToArray(e => new SnapshotAttr(e.Name, e.Value));



	private static U[] SelectToArray<T, U>(this IEnumerable<T> source, Func<T, U> mapFun) => source.Select(mapFun).ToArray();
}
*/