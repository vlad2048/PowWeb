﻿using PowBasics.Geom;

namespace PowWeb._Internal.Logic.SnapshotConversion.Utils;

static class DomRExt
{
	public static R ToR(this double[] arr) => new(
		(int)arr[0],
		(int)arr[1],
		(int)arr[2],
		(int)arr[3]
	);
}