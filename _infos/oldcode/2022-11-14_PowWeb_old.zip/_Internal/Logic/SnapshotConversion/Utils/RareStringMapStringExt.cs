﻿namespace PowWeb._Internal.Logic.SnapshotConversion.Utils;

static class RareStringMapStringExt
{
	public static T? Parse<T>(this string? str, Func<string, T> parseFun) where T : struct
		=> str switch {
			null => null,
			not null => parseFun(str)
		};
}