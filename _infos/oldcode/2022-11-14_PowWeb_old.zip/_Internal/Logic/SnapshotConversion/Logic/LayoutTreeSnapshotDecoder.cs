﻿using PowBasics.Geom;
using PowWeb._Internal.ChromeDevApi.DDomSnapshot.Structs;
using PowWeb._Internal.Logic.SnapshotConversion.Maps;
using PowWeb._Internal.Logic.SnapshotConversion.Structs;
using PowWeb._Internal.Logic.SnapshotConversion.Utils;

namespace PowWeb._Internal.Logic.SnapshotConversion.Logic;

static class LayoutTreeSnapshotDecoder
{
	public static LayRec[] Decode(LayoutTreeSnapshot lays, Ctx ctx)
	{
		var cnt = lays.NodeIndex.Length;
		var arr = new LayRec[cnt];

		// @formatter:off
		var stackingContexts = new RareBooleanMap(lays.StackingContexts);

		for (var i = 0; i < cnt; i++)
		{
			arr[i] = new LayRec(
				Index:						lays.NodeIndex[i],
				Styles:						ctx.ReadStrArr(lays.Styles[i]),
				Bounds:						lays.Bounds[i].ToR(),
				Text:						ctx.ReadStr(lays.Text[i]),
				StackingContexts:			stackingContexts.Get(i),
				PaintOrders:				lays.PaintOrders.ReadIntOpt(i),
				OffsetRects:				lays.OffsetRects.ReadROpt(i),
				ScrollRects:				lays.ScrollRects.ReadROpt(i),
				ClientRects:				lays.ClientRects.ReadROpt(i),
				BlendedBackgroundColors:	ctx.ReadStrOpt(lays.BlendedBackgroundColors, i),
				TextColorOpacities:			lays.TextColorOpacities.ReadDoubleOpt(i)
			);
		}

		// @formatter:on

		var normalizedArr = arr
			.GroupBy(e => e.Index)
			.Select(e => e
				.OrderByDescending(f => f.Text.Length)
				.ThenByDescending(f => f.Bounds.Width * f.Bounds.Height)
				.Take(1)
			)
			.SelectMany(e => e)
			.ToArray();

		return normalizedArr;
	}
}