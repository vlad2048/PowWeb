﻿using PowWeb._Internal.ChromeDevApi.DDomSnapshot.Enums;
using PowWeb._Internal.ChromeDevApi.DDomSnapshot.Structs;
using PowWeb._Internal.Logic.SnapshotConversion.Maps;
using PowWeb._Internal.Logic.SnapshotConversion.Structs;
using PowWeb._Internal.Logic.SnapshotConversion.Utils;

namespace PowWeb._Internal.Logic.SnapshotConversion.Logic;

static class NodeTreeSnapshotDecoder
{
	public static NodeRec[] Decode(NodeTreeSnapshot nodes, Ctx ctx)
	{
		var cnt = nodes.NodeType.Length;
		var arr = new NodeRec[cnt];

		// @formatter:off
		var shadowRootTypeMap		= new RareStringMap(nodes.ShadowRootType, ctx);
		var textValueMap			= new RareStringMap(nodes.TextValue, ctx);
		var inputValueMap			= new RareStringMap(nodes.InputValue, ctx);
		var pseudoTypeMap			= new RareStringMap(nodes.PseudoType, ctx);
		var pseudoIdentifierMap		= new RareStringMap(nodes.PseudoIdentifier, ctx);
		var currentSourceURLMap		= new RareStringMap(nodes.CurrentSourceURL, ctx);
		var originlURLMap			= new RareStringMap(nodes.OriginURL, ctx);

		var inputCheckedMap			= new RareBooleanMap(nodes.InputChecked);
		var optionSelectedMap		= new RareBooleanMap(nodes.OptionSelected);
		var isClickableMap			= new RareBooleanMap(nodes.IsClickable);

		var contentDocumentIndexMap	= new RareIntegerMap(nodes.ContentDocumentIndex);

		for (var i = 0; i < cnt; i++) {
			arr[i] = new NodeRec(
				Index:					i,
				ParentIndex: 			nodes.ParentIndex.ReadInt(i),
				NodeType:				(DomNodeType)nodes.NodeType.ReadInt(i),
				ShadowRootType:			shadowRootTypeMap.ReadStrAsShadowRootTypeOpt(i),
				Name:					ctx.ReadStr(nodes.NodeName, i),
				Value:					ctx.ReadStr(nodes.NodeValue, i),
				BackendNodeId:			nodes.BackendNodeId.GetAt(i),
				Attrs:					AttrRec.Decode(nodes.Attributes, i, ctx),
				TextValue:				textValueMap.Get(i),
				InputValue:				inputValueMap.Get(i),
				InputChecked:			inputCheckedMap.Get(i),
				OptionSelected:			optionSelectedMap.Get(i),
				ContentDocumentIndex:	contentDocumentIndexMap.Get(i),
				PseudoType:				pseudoTypeMap.Get(i),
				PseudoIdentifier:		pseudoIdentifierMap.Get(i),
				IsClickable:			isClickableMap.Get(i),
				CurrentSourceURL:		currentSourceURLMap.Get(i),
				OriginURL:				originlURLMap.Get(i)
			);
		}
		// @formatter:on

		return arr;
	}

	private static int GetAt(this int[]? arr, int idx) => arr switch
	{
		not null => arr[idx],
		null => -1
	};
}