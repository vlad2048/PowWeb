﻿using PowWeb._Internal.ChromeDevApi.DNetwork.Enums;
using PowWeb._Internal.ChromeDevApi.DNetwork.Structs;
using PowWeb._Internal.ChromeDevApi.Utils.Attributes;

namespace PowWeb._Internal.ChromeDevApi.DNetwork.Events;

[ChromeEvent("Network.requestWillBeSentEvent")]
record RequestWillBeSentEvent(
	string RequestId,
	string LoaderId,
	string DocumentUrl,
	Request Request,
	int Timestamp,
	int WallTime,
	Initiator Initiator,
	bool RedirectHasExtraInfo,
	Response? RedirectResponse,
	ResourceType? Type,
	string? FrameId,
	bool? HasUserGesture
);