﻿namespace PowWeb._Internal.ChromeDevApi.DNetwork.Structs;

record PostDataEntry(
	string? Bytes
);