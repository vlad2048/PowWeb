﻿namespace PowWeb._Internal.ChromeDevApi.DNetwork.Structs;

record ResourceTiming(
	int RequestTime,
	int ProxyStart
	// ...
);