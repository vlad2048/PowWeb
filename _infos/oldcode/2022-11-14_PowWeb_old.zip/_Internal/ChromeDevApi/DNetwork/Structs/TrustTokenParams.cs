﻿namespace PowWeb._Internal.ChromeDevApi.DNetwork.Structs;

record TrustTokenParams(
	string Type,
	string RefreshPolicy,
	string[]? Issuers
);