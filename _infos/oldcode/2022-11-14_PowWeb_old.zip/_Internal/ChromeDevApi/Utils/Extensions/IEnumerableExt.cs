﻿namespace PowWeb._Internal.ChromeDevApi.Utils.Extensions;

static class IEnumerableExt
{
	public static U[] SelectToArray<T, U>(this IEnumerable<T> source, Func<T, U> mapFun) => source.Select(mapFun).ToArray();
}