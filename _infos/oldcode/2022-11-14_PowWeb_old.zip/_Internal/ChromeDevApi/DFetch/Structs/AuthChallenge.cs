﻿namespace PowWeb._Internal.ChromeDevApi.DFetch.Structs;

record AuthChallenge(
	string? Source,
	string Origin,
	string Scheme,
	string Realm
);