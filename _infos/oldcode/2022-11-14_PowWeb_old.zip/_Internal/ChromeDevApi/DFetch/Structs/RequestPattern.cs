﻿using PowWeb._Internal.ChromeDevApi.DFetch.Enums;

namespace PowWeb._Internal.ChromeDevApi.DFetch.Structs;

record RequestPattern(
	string? UrlPattern,
	//DNetwork.Enums.ResourceType? ResourceType,
	string? ResourceType,
	string? RequestStage
);