﻿namespace PowWeb._Internal.ChromeDevApi.DFetch.Structs;

record HeaderEntry(
	string Name,
	string Value
);