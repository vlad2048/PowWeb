﻿using PowWeb._Internal.ChromeDevApi.DFetch.Structs;
using PowWeb._Internal.ChromeDevApi.Utils.Attributes;

namespace PowWeb._Internal.ChromeDevApi.DFetch.Events;

[ChromeEvent("Fetch.authRequired")]
record AuthRequiredEvent(
	string RequestId,
	DNetwork.Structs.Request Request,
	string FrameId,
	DNetwork.Enums.ResourceType ResourceType,
	AuthChallenge AuthChallenge
);