﻿namespace PowWeb._Internal.ChromeDevApi.DFetch.Enums;

enum RequestStage
{
	request,
	response
}