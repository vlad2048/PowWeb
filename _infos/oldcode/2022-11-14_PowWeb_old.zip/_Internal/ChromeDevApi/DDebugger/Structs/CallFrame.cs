﻿using PowWeb._Internal.ChromeDevApi.DRuntime.Structs;

namespace PowWeb._Internal.ChromeDevApi.DDebugger.Structs;

record CallFrame(
	string CallFrameId,
	string FunctionName,
	Location? FunctionLocation,
	Location Location,
	string Url,
	Scope[] ScopeChain,
	RemoteObject This,
	RemoteObject ReturnValue,
	bool CanBeRestarted
);