﻿using PowWeb._Internal.ChromeDevApi.DRuntime.Structs;

namespace PowWeb._Internal.ChromeDevApi.DDebugger.Structs;

record Scope(
	string Type,
	RemoteObject Object,
	string Name,
	Location StartLocation,
	Location EndLocation
);