﻿namespace PowWeb._Internal.ChromeDevApi.DDebugger.Structs;

record DebugSymbols(
	string Type,
	string? ExternalUrl
);