﻿namespace PowWeb._Internal.ChromeDevApi.DDebugger.Enums;

enum ExceptionPauseState
{
	None,
	Uncaught,
	All
}