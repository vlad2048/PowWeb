﻿namespace PowWeb._Internal.ChromeDevApi.DDebugger.Enums;

enum Instrumentation
{
	BeforeScriptExecution,
	BeforeScriptWithSourceMapExecution
}