﻿namespace PowWeb._Internal.ChromeDevApi.DDomSnapshot.Enums;

public enum DomShadowRootType
{
	userAgent = 0,
	open = 1,
	closed = 2
}