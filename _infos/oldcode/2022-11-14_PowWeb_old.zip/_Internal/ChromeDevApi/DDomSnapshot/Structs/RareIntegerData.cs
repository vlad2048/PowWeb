﻿namespace PowWeb._Internal.ChromeDevApi.DDomSnapshot.Structs;

record RareIntegerData(
	int[] Index,
	int[] Value
);