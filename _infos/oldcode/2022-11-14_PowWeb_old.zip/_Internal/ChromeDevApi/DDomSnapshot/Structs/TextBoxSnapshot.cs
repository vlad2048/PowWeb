﻿namespace PowWeb._Internal.ChromeDevApi.DDomSnapshot.Structs;

record TextBoxSnapshot(
	int[] LayoutIndex,
	double[][] Bounds,
	int[] Start,
	int[] Length
);