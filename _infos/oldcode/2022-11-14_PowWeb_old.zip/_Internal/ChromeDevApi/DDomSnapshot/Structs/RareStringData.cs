﻿namespace PowWeb._Internal.ChromeDevApi.DDomSnapshot.Structs;

record RareStringData(
	int[] Index,
	int[] Value
);