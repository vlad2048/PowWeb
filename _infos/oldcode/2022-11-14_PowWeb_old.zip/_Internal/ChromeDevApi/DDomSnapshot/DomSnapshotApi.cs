﻿using PowWeb._Internal.ChromeDevApi.Utils;
using PowWeb._Internal.ChromeDevApi.DDomSnapshot.Structs;
using PuppeteerSharp;

namespace PowWeb._Internal.ChromeDevApi.DDomSnapshot;

static class DomSnapshotApi
{
	public record DomSnapshot_CaptureSnapshot_Ret(DocumentSnapshot[] Documents, string[] Strings);
	public static DomSnapshot_CaptureSnapshot_Ret DomSnapshot_CaptureSnapshot(
		this CDPSession client,
		string[] computedStyles,
		bool? includePaintOrder = null,
		bool? includeDOMRects = null,
		bool? includeBlendedBackgroundColors = null,
		bool? includeTextColorOpacities = null
	) =>
		client.Send<DomSnapshot_CaptureSnapshot_Ret>(
			"DOMSnapshot.captureSnapshot",
			new
			{
				ComputedStyles = computedStyles,
				IncludePaintOrder = includePaintOrder,
				IncludeDOMRects = includeDOMRects,
				IncludeBlendedBackgroundColors = includeBlendedBackgroundColors,
				IncludeTextColorOpacities = includeTextColorOpacities
			}
		);
}