﻿namespace PowWeb._Internal.ChromeDevApi.DRuntime.Structs;

record StackTraceId(
	string Id,
	string UniqueDebuggerId
);