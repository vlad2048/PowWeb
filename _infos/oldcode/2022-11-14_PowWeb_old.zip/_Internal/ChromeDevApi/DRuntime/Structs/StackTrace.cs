﻿namespace PowWeb._Internal.ChromeDevApi.DRuntime.Structs;

record StackTrace(
	string? Description,
	CallFrame[] CallFrames,
	StackTrace? Parent,
	StackTraceId? ParentId
);