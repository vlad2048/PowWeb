﻿namespace PowWeb._Internal.ChromeDevApi.DRuntime.Structs;

record EntryPreview(
	ObjectPreview Key,
	ObjectPreview Value
);