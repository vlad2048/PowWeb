﻿namespace PowWeb._Internal.ChromeDevApi.DRuntime.Structs;

record PropertyPreview(
	string Name,
	string Type,
	string? Value,
	RemoteObject? ValuePreview,
	string Subtype
);