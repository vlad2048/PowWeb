﻿namespace PowWeb._Internal.ChromeDevApi.DRuntime.Structs;

record CallFrame(
	string FunctionName,
	string ScriptId,
	string Url,
	int LineNumber,
	int ColumnNumber
);