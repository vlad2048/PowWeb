﻿namespace PowWeb._Internal.ChromeDevApi.DRuntime.Structs;

record WebDriverValue(
	string Type,
	object? Value,
	string? ObjectId
);