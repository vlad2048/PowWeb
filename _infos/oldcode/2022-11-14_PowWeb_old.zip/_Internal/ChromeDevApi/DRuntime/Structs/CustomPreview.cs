﻿namespace PowWeb._Internal.ChromeDevApi.DRuntime.Structs;

record CustomPreview(
	string Header,
	string? RemoteObjectId
);