﻿using PowWeb._Internal.ChromeDevApi.DRuntime.Structs;
using PowWeb._Internal.ChromeDevApi.Utils;
using PuppeteerSharp;

namespace PowWeb._Internal.ChromeDevApi.DRuntime;

static class RuntimeApi
{
	public record Runtime_Evaluate_Ret(RemoteObject Result, ExceptionDetails? ExceptionDetails);
	public static Runtime_Evaluate_Ret Runtime_Evaluate(
		this CDPSession client,
		string expression
	) =>
		client.Send<Runtime_Evaluate_Ret>("Runtime.evaluate", new
		{
			Expression = expression
		});
}