﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("LINQPadQuery")]
[assembly: InternalsVisibleTo("WebPlay")]