﻿using System.Text.Json;
using PowBasics.Geom.Serializers;
using PowTrees.Serializer;
using PowWeb.Structs.SnapshotLiteStructs;
using PowWeb.Structs.SnapshotStructs;

namespace PowWeb.Utils;

public static class JsonUtils
{
	public static JsonSerializerOptions JsonOpt { get; } = new()
	{
		WriteIndented = true
	};
	static JsonUtils()
	{
		JsonOpt.Converters.Add(new TNodSerializer<SnapshotNode>());
		JsonOpt.Converters.Add(new TNodSerializer<CapNode>());
		JsonOpt.Converters.Add(new PtSerializer());
		JsonOpt.Converters.Add(new RSerializer());
		JsonOpt.Converters.Add(new SzSerializer());
	}

	public static void Save<T>(string file, T obj)
	{
		var str = JsonSerializer.Serialize(obj, JsonOpt);
		File.WriteAllText(file, str);
	}

	public static T Load<T>(string file)
	{
		var str = File.ReadAllText(file);
		var obj = JsonSerializer.Deserialize<T>(str, JsonOpt);
		return obj!;
	}
}