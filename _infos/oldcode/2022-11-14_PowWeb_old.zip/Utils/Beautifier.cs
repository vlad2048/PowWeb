﻿using AngleSharp.Html;
using AngleSharp.Html.Parser;
using Jsbeautifier;

namespace PowWeb.Utils;

public static class Beautifier
{
	public static string Html(string html)
	{
		var parser = new HtmlParser();
		var doc = parser.ParseDocument(html);
		using var writer = new StringWriter();
		doc.ToHtml(writer, new PrettyMarkupFormatter
		{
			Indentation = "\t",
			NewLine = "\n"
		});
		var formattedHtml = writer.ToString();
		return formattedHtml;
	}
	
	public static string Js(string js)
	{
		var opt = new BeautifierOptions
		{
			IndentSize = 2,
			IndentChar = ' ',
			BraceStyle = BraceStyle.Collapse,
			BreakChainedMethods = false,
		};
		var beautifier = new Jsbeautifier.Beautifier(opt);
		var fmtJs = beautifier.Beautify(js);
		return fmtJs;
	}
}