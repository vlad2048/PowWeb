﻿namespace PowWeb.Functionality.Web_Capture_Utils;

public enum ScreenCapType
{
	None,
	Builtin,
	ScrollAndAssemble
}

public class CapOpt
{
	public bool EnableFrameTreeMerging { get; set; }
	public string[] NodeNamesToRemove { get; set; } = { "#comment" };
	public bool CaptureBodyOnly { get; set; } = true;
	public bool DiscardNodesWithoutRectangles { get; set; } = true;
	public bool RemoveEmptyTextNodes { get; set; } = true;
	public bool DisplayPerf { get; set; } = false;
	public ScreenCapType ScreenCapType { get; set; } = ScreenCapType.ScrollAndAssemble;

	internal static CapOpt Build(Action<CapOpt>? action)
	{
		var opt = new CapOpt();
		action?.Invoke(opt);
		return opt;
	}
}