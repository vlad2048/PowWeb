﻿using PowTrees.Algorithms;
using PowWeb.Structs.SnapshotLiteStructs;

namespace PowWeb.Functionality.Web_Capture_Utils;

static class FrameMatcher
{
	private record Anchor(TNod<CapNode> AnchorNod, string? Src)
	{
		public override string ToString() => $@"Anchor: ""{Src}""";
	}

	private record MatchResult(List<(Anchor, Web_Capture.NamedRoot)> Matches, Anchor[] UnmatchedAnchors, Web_Capture.NamedRoot[] UnmatchedRoots)
	{
		public override string ToString() => $"Matches:{Matches.Count}  (UnmatchedAnchors:{UnmatchedAnchors.Length}  UnmatchedRoots:{UnmatchedRoots.Length})";
	}

	public static TNod<CapNode> AttachFrameRoots(Web_Capture.NamedRoot[] roots)
	{
		var finalRoot = AttachFrameRootsInner(roots);
		//LogRoots(roots, finalRoot);
		return finalRoot;
	}

	private static TNod<CapNode> AttachFrameRootsInner(Web_Capture.NamedRoot[] roots)
	{
		var anchors = (
			from root in roots
			from nod in root.Root
			where nod.V.Name == "IFRAME"
			select new Anchor(nod, nod.V.GetAttr("src"))
		).ToArray();

		static bool IsIssue(TNod<CapNode> root) => root.GroupBy(e => e.V.Index).Where(e => e.Count() > 1).ToArray().Length > 0;

		var res = MatchWithAll(anchors, roots.Skip(1).ToArray());

		/*if (res.UnmatchedAnchors.Any() || res.UnmatchedRoots.Any())
		{
			throw new ArgumentException();
		}*/

		foreach (var match in res.Matches)
		{
			var (anchor, root) = match;
			
			var idxStart = anchor.AnchorNod.GetRoot().Max(e => e.V.Index) + 1;
			var reindexedRoot = root.Root.Map(e => e with { Index = e.Index + idxStart });
			anchor.AnchorNod.AddChild(reindexedRoot);
		}

		return roots[0].Root;
	}

	private static TNod<CapNode> GetRoot(this TNod<CapNode> nod)
	{
		while (nod.Parent != null)
			nod = nod.Parent;
		return nod;
	}

	private static MatchResult MatchWithAll(Anchor[] anchors, Web_Capture.NamedRoot[] roots)
	{
		Func<string, string>[] mapFuncs =
		{
			UrlUtils.Id,
			UrlUtils.RemoveUrlParams,
			UrlUtils.GetDomain,
			UrlUtils.True,
		};

		var matches = new MatchResult[mapFuncs.Length];

		var matchPrev = new MatchResult(new List<(Anchor, Web_Capture.NamedRoot)>(), anchors, roots);

		for (var i = 0; i < mapFuncs.Length; i++)
		{
			var mapFun = mapFuncs[i];
			var matchNext = MatchWith(matchPrev, MakeCmp(mapFun));
			matches[i] = matchNext;
			matchPrev = matchNext;
		}

		return matchPrev;
	}

	public static Func<string, string, bool> MakeCmp(Func<string, string> mapFun) => (a, b) => string.Compare(mapFun(a), mapFun(b), StringComparison.OrdinalIgnoreCase) == 0;


	private static MatchResult MatchWith(MatchResult srcData, Func<string, string, bool> matchFun)
	{
		var dstData = MatchAnchorsToRoots(srcData.UnmatchedAnchors, srcData.UnmatchedRoots, matchFun);
		dstData.Matches.AddRange(srcData.Matches);
		return dstData;
	}



	private static MatchResult MatchAnchorsToRoots(Anchor[] anchorsArr, Web_Capture.NamedRoot[] rootsArr, Func<string, string, bool> matchFun)
	{
		bool IsMatch(string? anchorName, string rootName)
		{
			if (anchorName == null) return string.IsNullOrWhiteSpace(rootName);
			return matchFun(
				UrlUtils.PreProcess(anchorName),
				UrlUtils.PreProcess(rootName)
			);
		}

		var anchors = anchorsArr.ToList();
		var roots = rootsArr.ToList();
		var matches = new List<(Anchor, Web_Capture.NamedRoot)>();
		var unmatchedAnchors = new List<Anchor>();
		foreach (var anchor in anchors)
		{
			var matchedRoot = roots.FirstOrDefault(root => IsMatch(anchor.Src, root.Name));
			if (matchedRoot != null)
			{
				matches.Add((anchor, matchedRoot));
				roots.Remove(matchedRoot);
			}
			else
			{
				unmatchedAnchors.Add(anchor);
			}
		}
		return new MatchResult(
			matches,
			unmatchedAnchors.ToArray(),
			roots.ToArray()
		);
	}


	private static void LogRoots(Web_Capture.NamedRoot[] roots, TNod<CapNode> finalRoot)
	{
		static string Fmt(CapNode n) => (n.Name == "IFRAME") switch
		{
			true => $"IFRAME({n.GetAttr("src")})",
			false => n.Name
		};

		LogTitle($"Roots: {roots.Length}");
		for (var i = 0; i < roots.Length; i++)
		{
			Log($"  Root[{i}]");
			Log(roots[i].Root.LogToString(opt =>
			{
				opt.LeadingSpaceCount = 4;
				opt.FormatFun = Fmt;
			}));
		}
		Log("");

		LogTitle("Final Root");
		Log(finalRoot.LogToString(opt =>
		{
			opt.LeadingSpaceCount = 2;
			opt.FormatFun = Fmt;
		}));
	}

	private static void Log(string str) => Console.WriteLine(str);
	private static void LogTitle(string str) { Log(str); Log(new string('=', str.Length)); }
}