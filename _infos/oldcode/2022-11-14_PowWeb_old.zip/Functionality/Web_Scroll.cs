﻿using PowBasics.Geom;

// ReSharper disable once CheckNamespace
namespace PowWeb;

public static class Web_Scroll
{
	public static void ScrollTo(this Web web, Pt pos)
	{
		web.Page.EvaluateExpressionAsync($@"
			document.documentElement.scrollLeft = {pos.X};
			document.documentElement.scrollTop = {pos.Y};
		").Wait();
	}
}