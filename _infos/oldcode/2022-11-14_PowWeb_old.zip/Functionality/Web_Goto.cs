﻿using PuppeteerSharp;

// ReSharper disable once CheckNamespace
namespace PowWeb;

public static class Web_Goto
{
	public static void Goto(this Web web, string url)
	{
		try
		{
			web.Page.GoToAsync(url, WaitUntilNavigation.Networkidle2).Wait();
			web.CurrentUrl = url;
		}
		catch (AggregateException aggEx)
		{
			var exType = ClassifyEx(aggEx);
			switch (exType)
			{
				case ExType.TargetClosed:
					Console.WriteLine("[Web Exception] TargetClosedException -> ignoring");
					break;

				case ExType.Timeout:
					Console.WriteLine("[Web Exception] Timeout -> ignoring");
					break;

				case ExType.NetErrAborted:
					Console.WriteLine("[Web Exception] NetErrAborted -> ignoring");
					throw;

				case ExType.Unknown:
					Console.WriteLine("[Web Exception] Unknown -> rethrowing");
					throw;

				default:
					throw new ArgumentException();
			}
		}
	}

	private enum ExType
	{
		Unknown,
		TargetClosed,
		Timeout,
		NetErrAborted
	}

	private static ExType ClassifyEx(Exception ex)
	{
		if (ex is not AggregateException aggEx) return ExType.Unknown;
		if (aggEx.InnerExceptions.Count != 1) return ExType.Unknown;
		var aggExInner = aggEx.InnerExceptions[0];
		if (aggExInner is not NavigationException navigationEx) return ExType.Unknown;
		return navigationEx.InnerException switch
		{
			TargetClosedException => ExType.TargetClosed,
			TimeoutException => ExType.Timeout,
			NavigationException navEx when navEx.Message.StartsWith("net::ERR_ABORTED") => ExType.NetErrAborted,
			_ => ExType.Unknown
		};
	}
}