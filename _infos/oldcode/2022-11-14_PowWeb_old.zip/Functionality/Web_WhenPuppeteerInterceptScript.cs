﻿using System.Net;
using System.Reactive.Linq;
using System.Text;
using PowMaybeErr;
using PowRxVar;
using PowWeb._Internal.ChromeDevApi.Utils.Extensions;
using PowWeb.Functionality.Web_WhenPuppeteerInterceptScript_Utils;
using PowWeb.Functionality.Web_WhenPuppeteerInterceptScript_Utils.Structs;
using PuppeteerSharp;

// ReSharper disable once CheckNamespace
namespace PowWeb;

public static class Web_WhenPuppeteerInterceptScript
{
	public static IObservable<PuppeteerScript> WhenPuppeteerScriptIntercepted(this Web web)
	{
		var page = web.Page;

		page.SetRequestInterceptionAsync(true).Wait();

		return Observable.Create<PuppeteerScript>(subj =>
		{
			var d = new Disp();
			var whenRequest = Observable.FromEventPattern<RequestEventArgs>(e => page.Request += e, e => page.Request -= e).Select(e => e.EventArgs.Request);


			whenRequest
				.Subscribe(async request =>
				{
					async Task<string?> FetchReq()
					{
						var mayRes = await PuppeteerInterceptScriptUtilsFetch.Fetch(request);
						if (mayRes.IsSome(out var res))
						{
							return res;
						}
						else
						{
							await request.ContinueAsync();
							return null;
						}

						/*async Task<string?> FetchReqInner()
						{
							var response = request.Response;
							if (response == null)
							{
								Console.WriteLine("No response");
								return null;
							}

							try
							{
								var bytes = await response.BufferAsync();
								var text = Encoding.UTF8.GetString(bytes);
								return text;
							}
							catch (Exception ex)
							{
								Console.WriteLine($"Exception getting buffer: {ex.Message}");
								return null;
							}
						}

						var res = await FetchReqInner();
						if (res == null)
						{
							await request.ContinueAsync();
						}
						return res;*/
					}

					async Task SendResponse(string body)
					{
						await request.RespondAsync(new ResponseData
						{
							Body = body,
							Status = HttpStatusCode.OK,
							ContentType = "text/html; charset=UTF-8",
						});
					}



					switch (request.ResourceType)
					{
						case ResourceType.Document:
						{
							var htmlPrev = await FetchReq();
							if (htmlPrev == null) return;
							var scriptBodies = PuppeteerInterceptScriptUtilsHtmlExtraction.ExtractScriptsFromHtml(htmlPrev);
							var scripts = new PuppeteerScript[scriptBodies.Length];
							for (var index = 0; index < scriptBodies.Length; index++)
							{
								var scriptBody = scriptBodies[index];
								scripts[index] = new PuppeteerScript(request.Url, index, scriptBody);
								subj.OnNext(scripts[index]);
							}
							var htmlNext = PuppeteerInterceptScriptUtilsHtmlExtraction.ReplaceScriptsInHtml(htmlPrev, scripts.SelectToArray(script => script.Body));
							await SendResponse(htmlNext);
							break;
						}

						case ResourceType.Script:
						{
							var scriptBody = await FetchReq();
							if (scriptBody == null) return;
							var script = new PuppeteerScript(request.Url, null, scriptBody);
							subj.OnNext(script);
							await SendResponse(script.Body);
							break;
						}

						default:
							//Console.WriteLine($"[{request.ResourceType}] '{request.Url}'");
							await request.ContinueAsync();
							break;
					}
				}).D(d);

			return d;
		});
	}
}