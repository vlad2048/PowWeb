﻿using PowTrees.Algorithms;
using PowWeb._Internal.Utils;
using PuppeteerSharp;

// ReSharper disable once CheckNamespace
namespace PowWeb;

public static class Web_LogPagesAndTargets
{
	public static void LogPagesAndTargets(this Web web)
	{
		static string FmtFrame(Frame frame)
		{
			var detachedStr = frame.Detached ? " (detached)" : string.Empty;
			var oopStr = frame.IsOopFrame ? " (oop)" : string.Empty;
			return $"[Name:{frame.Name} Url:{frame.Url.FmtUrlSimple()}{detachedStr}{oopStr}]";
		}
		web.Log(" ");
		web.Log("Browser Pages & Targets");
		web.Log("=======================");
		var pages = web.Browser.PagesAsync().Result;
		web.Log($"Pages:{pages.Length}");
		for (var i = 0; i < pages.Length; i++)
		{
			var page = pages[i];
			var frameStr = $" frames:{page.Frames.Length}";
			web.Log($"  [{i}]: '{page.Url.FmtUrlSimple()}'{frameStr}");
			var frameRoot = BrowserUtils.GetFrameTree(page);
			var frameRootStr = frameRoot.Map(FmtFrame);
			web.Log(frameRootStr.LogToString(logOpt =>
			{
				logOpt.LeadingSpaceCount = 4;
			}));
		}

		var targets = web.Browser.Targets();
		web.Log($"Targets:{targets.Length}");
		for (var i = 0; i < targets.Length; i++)
		{
			var target = targets[i];
			var typeStr = $"{target.Type}".PadRight(20);
			web.Log($"  [{i}]: {typeStr} '{target.Url.FmtUrlSimple()}'");
		}
		web.Log(" ");
	}
}