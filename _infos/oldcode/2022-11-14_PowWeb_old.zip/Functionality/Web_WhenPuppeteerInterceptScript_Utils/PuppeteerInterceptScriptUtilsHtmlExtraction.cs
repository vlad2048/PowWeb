﻿using PowMaybeErr;

namespace PowWeb.Functionality.Web_WhenPuppeteerInterceptScript_Utils;

static class PuppeteerInterceptScriptUtilsHtmlExtraction
{
	private const string ScriptsXPath = "//script[ (not(@type) or @type='text/javascript') and not(@src) ]";

	public static string[] ExtractScriptsFromHtml(string html)
	{
		var mayNodes =
			from root in Html.GetRoot(html)
			from queryNodes in root.QueryNodes(ScriptsXPath)
			select queryNodes.ToArray();
		if (mayNodes.IsNone(out var nodes, out _))
			return Array.Empty<string>();
		return nodes.Select(node => node.InnerText).ToArray();
	}

	public static string ReplaceScriptsInHtml(string html, string[] scripts)
	{
		var mayRootNodes =
			from _root in Html.GetRoot(html)
			from queryNodes in _root.QueryNodes(ScriptsXPath)
			select (_root, queryNodes.ToArray());
		if (mayRootNodes.IsNone(out var rootNodes, out _))
			return html;
		var (root, nodes) = rootNodes;
		if (nodes.Length != scripts.Length) throw new ArgumentException("Wrong number of scripts");

		nodes.Zip(scripts).ForEach(t => t.First.InnerHtml = t.Second);
		return root.OuterHtml;
	}

	private static void ForEach<T>(this IEnumerable<T> source, Action<T> action)
	{
		foreach (var elt in source)
			action(elt);
	}
}