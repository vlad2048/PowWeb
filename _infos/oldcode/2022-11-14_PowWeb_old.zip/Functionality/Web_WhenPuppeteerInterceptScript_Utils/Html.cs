﻿using System.Xml.XPath;
using HtmlAgilityPack;
using PowMaybe;
using PowMaybeErr;
using HtmlDocument = HtmlAgilityPack.HtmlDocument;

namespace PowWeb.Functionality.Web_WhenPuppeteerInterceptScript_Utils;

static class Html
{
	public static MaybeErr<HtmlNode> GetRoot(string html)
	{
		try
		{
			var doc = new HtmlDocument();
			doc.LoadHtml(html);
			return MayErr.Some(doc.DocumentNode);
		}
		catch (Exception ex)
		{
			return MayErr.None<HtmlNode>(ex.Message);
		}
	}


	/// <summary>
	/// Gets the first node matching an xPath
	/// or return the parent if xPath is null
	/// </summary>
	public static MaybeErr<HtmlNode> QueryNode(this HtmlNode parent, string? xPath)
	{
		try
		{
			if (xPath == null)
				return MayErr.Some(parent);
			var node = parent.SelectSingleNode(xPath);
			if (node == null)
				//return MayErr.None<HtmlNode>(new XPathScrapeErr(null, parent, xPath));
				return MayErr.None<HtmlNode>("xpath: node == null");
			return MayErr.Some(node);
		}
		catch (XPathException ex)
		{
			//var err = new XPathExceptionScrapeErr(null, parent, xPath, ex);
			return MayErr.None<HtmlNode>($"xpath: {ex.Message}");
		}
	}


	/// <summary>
	/// Gets all the nodes matching an XPath
	/// </summary>
	public static MaybeErr<List<HtmlNode>> QueryNodes(this HtmlNode parent, string xPath)
	{
		try
		{
			var nodes = parent.SelectNodes(xPath);
			if (nodes == null)
				//return MayErr.None<List<HtmlNode>>(new XPathScrapeErr(null, parent, xPath));
				return MayErr.None<List<HtmlNode>>("xpath: nodes == null");
			var nodeList = nodes.ToList();
			if (nodeList.Count == 0)
				//return MayErr.None<List<HtmlNode>>(new XPathScrapeErr(null, parent, xPath));
				return MayErr.None<List<HtmlNode>>("xpath: nodeList.Count == 0");
			return MayErr.Some(nodeList);
		}
		catch (XPathException ex)
		{
			//var err = new XPathExceptionScrapeErr(null, parent, xPath, ex);
			return MayErr.None<List<HtmlNode>>(ex.Message);
		}
	}


	/// <summary>
	/// Parse a node into a data object using a lambda
	/// </summary>
	public static MaybeErr<List<Maybe<T>>> ParseNodes<T>(this List<HtmlNode> nodes, Func<HtmlNode, Maybe<T>> parseFun) =>
		from structs in MayErr.Some(nodes.Select(parseFun).ToList())
		select structs;


	/// <summary>
	/// Parse the InnerText of a node (or a child using xPath) into a T
	/// </summary>
	public static MaybeErr<T> GetText<T>(this HtmlNode parent, string? xPath = null) =>
		from subNode in parent.QueryNode(xPath)
		from subNodeValue in Convert<T>(subNode.InnerText)
		select subNodeValue;


	/// <summary>
	/// Parse an attribute value of a node (or a child using xPath) into a T
	/// </summary>
	public static MaybeErr<T> GetAttr<T>(this HtmlNode parent, string attrName, string? xPath = null) =>
		from subNode in parent.QueryNode(xPath)
		from attrValue in subNode.GetAttrInternal(attrName)
		from attrParsed in Convert<T>(attrValue)
		select attrParsed;

	public static MaybeErr<bool> IsTextFound<T>(this HtmlNode parent, T cmp, string? xPath = null)
		where T : IEquatable<T>
	{
		var text = parent.GetText<T>(xPath);
		return text switch
		{
			Some<T> { Value: var val } => MayErr.Some(val.Equals(cmp)),
			None<T> => MayErr.Some(false),
			_ => throw new ArgumentException()
		};
	}

	private static MaybeErr<T> Convert<T>(string str)
	{
		str = str.Trim();

		if (typeof(T) == typeof(int))
		{
			if (int.TryParse(str, out var resInt))
				return MayErr.Some((T)(object)resInt);
			return MayErr.None<T>($"Could not parse '{str}' as an int");
		}

		if (typeof(T) == typeof(string))
			return MayErr.Some((T)(object)str);

		return MayErr.None<T>($"Do not know how to parse type: {typeof(T).Name}  str:'{str}'");
	}

	private static MaybeErr<string> GetAttrInternal(this HtmlNode node, string attrName)
	{
		if (!node.Attributes.Contains(attrName))
			//return MayErr.None<string>(new MissingAttributeScrapeErr(null, node, attrName));
			return MayErr.None<string>($"GetAttrInternal: missing attribute '{attrName}'");
		var attr = node.Attributes[attrName];
		return MayErr.Some(attr.Value);
	}
}