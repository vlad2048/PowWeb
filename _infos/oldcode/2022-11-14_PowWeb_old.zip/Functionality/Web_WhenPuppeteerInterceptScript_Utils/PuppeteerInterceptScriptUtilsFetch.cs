﻿using PowMaybeErr;
using PuppeteerSharp;
using RestSharp;

namespace PowWeb.Functionality.Web_WhenPuppeteerInterceptScript_Utils;

static class PuppeteerInterceptScriptUtilsFetch
{
	private static readonly Lazy<RestClient> client = new(() => new RestClient());
	private static RestClient Client => client.Value;

	public static async Task<MaybeErr<string>> Fetch(Request request)
	{
		static Method Conv(HttpMethod e)
		{
			if (e == HttpMethod.Delete) return Method.Delete;
			if (e == HttpMethod.Get) return Method.Get;
			if (e == HttpMethod.Head) return Method.Head;
			if (e == HttpMethod.Options) return Method.Options;
			if (e == HttpMethod.Patch) return Method.Patch;
			if (e == HttpMethod.Post) return Method.Post;
			if (e == HttpMethod.Put) return Method.Put;
			throw new ArgumentException("Failed to convert HttpMethod");
		}

		var restRequest = new RestRequest(
			request.Url,
			Conv(request.Method)
		);
		var res = await Client.ExecuteAsync(restRequest);
		var content = res.Content;
		if (!res.IsSuccessful || content == null) return MayErr.None<string>($"{res.StatusDescription} / {content}");
		return MayErr.Some(content);
	}
}