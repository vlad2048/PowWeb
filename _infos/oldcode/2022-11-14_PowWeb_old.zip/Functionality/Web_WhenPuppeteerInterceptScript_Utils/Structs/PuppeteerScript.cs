﻿namespace PowWeb.Functionality.Web_WhenPuppeteerInterceptScript_Utils.Structs;

public class PuppeteerScript
{
	public string Url { get; }
	public int? Index { get; }
	public string Body { get; set; }

	public PuppeteerScript(string url, int? index, string body)
	{
		Url = url;
		Index = index;
		Body = body;
	}
}
