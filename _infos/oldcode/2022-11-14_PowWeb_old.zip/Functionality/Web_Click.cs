﻿using PowBasics.Geom;
using PowWeb._Internal.ActionTracking;
using PowWeb._Internal.ActionTracking.Structs;
using PowWeb.Structs.SnapshotLiteStructs;
using PowWeb.Structs.SnapshotStructs;
using PuppeteerSharp;
using PuppeteerSharp.Input;

// ReSharper disable once CheckNamespace
namespace PowWeb;

public class ClickOpt
{
	public TimeSpan ClickDelay { get; set; } = TimeSpan.FromMilliseconds(1000);
	public bool WaitForDOMContentLoadedEvent { get; set; }
	public TimeSpan Timeout { get; set; } = TimeSpan.FromMilliseconds(1000);

	private ClickOpt()
	{
	}

	internal static ClickOpt Build(Action<ClickOpt>? optFun)
	{
		var opt = new ClickOpt();
		optFun?.Invoke(opt);
		return opt;
	}
}


public static class Web_Click
{
	private static readonly Lazy<ActionMan> actionMan = new(() => new ActionMan());
	private static ActionMan ActionMan => actionMan.Value;


	public static void Click(this Web web, TNod<CapNode> nod, Action<ClickOpt>? optFun = null) => web.Click(nod.V.Bounds, optFun);

	public static void Click(this Web web, R nodR, Action<ClickOpt>? optFun = null)
	{
		if (nodR == R.Empty) return;
		web.Click(nodR.Center, optFun);
	}

	public static void Click(this Web web, Pt nodCenter, Action<ClickOpt>? optFun = null)
	{
		var opt = ClickOpt.Build(optFun);
		var page = web.Page;

		//Console.WriteLine($"Click @ {pos}");
		//ActionMan.SendCmd(new MouseClickTrackEvent(pos, opt.ClickDelay));
		//Thread.Sleep(opt.ClickDelay);

		var needScroll = nodCenter.X >= page.Viewport.Width || nodCenter.Y >= page.Viewport.Height;
		if (needScroll)
		{
			page.SetScroll(nodCenter);
			var scrollPt = page.GetScroll();
			nodCenter -= scrollPt;
		}

		page.Mouse.ClickAsync(nodCenter.X, nodCenter.Y).Wait();

		if (opt.WaitForDOMContentLoadedEvent)
		{
			var eventAwaiter = new EventAwaiter();
			page.DOMContentLoaded += eventAwaiter.Listen;
			eventAwaiter.Wait(opt.Timeout);
			page.DOMContentLoaded -= eventAwaiter.Listen;
		}

		//if (needScroll)
		//{
		//	page = web.Page;
		//	page.SetScroll(Pt.Empty);
		//}
	}


	public static Pt GetScroll(this Page page)
	{
		var x = page.EvaluateExpressionAsync("document.documentElement.scrollLeft").Result.ToObject<int>();
		var y = page.EvaluateExpressionAsync("document.documentElement.scrollTop").Result.ToObject<int>();
		return new Pt(x, y);
	}
	
	public static void SetScroll(this Page page, Pt pt)
	{
		page.EvaluateExpressionAsync($"document.documentElement.scrollLeft = {pt.X}").Wait();
		page.EvaluateExpressionAsync($"document.documentElement.scrollTop= {pt.Y}").Wait();
	}







	private class EventAwaiter
	{
		private bool isDisposed;
		private readonly ManualResetEventSlim slim = new();

		public void Listen(object? sender, EventArgs eventArgs) => slim.Set();

		public bool Wait(TimeSpan timeout)
		{
			if (isDisposed)
				throw new ObjectDisposedException(nameof(EventAwaiter));
			var isOk = slim.Wait(timeout);
			isDisposed = true;
			return isOk;
		}
	}
}