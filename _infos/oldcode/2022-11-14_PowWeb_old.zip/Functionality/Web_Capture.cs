﻿using System.Web;
using PowBasics.Geom;
using PowTrees.Algorithms;
using PowWeb._Internal;
using PowWeb._Internal.ChromeDevApi.DDomSnapshot;
using PowWeb._Internal.ChromeDevApi.DDomSnapshot.Enums;
using PowWeb._Internal.ChromeDevApi.Utils.Extensions;
using PowWeb._Internal.Logic.SnapshotConversion;
using PowWeb.Functionality.Web_Capture_Utils;
using PowWeb.Structs.SnapshotLiteStructs;
using PowWeb.Structs.SnapshotStructs;
using PuppeteerSharp;

// ReSharper disable once CheckNamespace
namespace PowWeb;

/*
  Timings:

  https://news.ycombinator.com/
  [Capture] Snapshot             -> 114.625ms
  [Capture] Convert              -> 4.060ms
  [Capture] Filter               -> 5.838ms
  [Capture] Screenshot           -> 199.873ms

  https://forumserver.twoplustwo.com/
  [Capture] Snapshot             -> 185.641ms
  [Capture] Convert              -> 34.240ms
  [Capture] Filter               -> 7.988ms
  [Capture] Screenshot           -> 538.403ms
*/

public static class Web_Capture
{
	internal record NamedRoot(TNod<CapNode> Root, string Name)
	{
		public override string ToString() => $@"""{Name}"" (nodes:{Root.Count()})";
	}

	public static Cap Capture(this Web web, Action<CapOpt>? optFun = null)
	{
		var opt = CapOpt.Build(optFun);

		var snapshot = web.CaptureFull(opt);
		if (snapshot.Docs.Length == 0) throw new ArgumentException("No documents loaded in the browser -> cannot capture");
		var docUrl = snapshot.Docs[0].DocumentUrl;

		var namedRoots = snapshot.Docs.SelectToArray(e => new NamedRoot(e.ToTree(), e.DocumentUrl));
		var root = opt.EnableFrameTreeMerging switch
		{
			true => FrameMatcher.AttachFrameRoots(namedRoots),
			false => namedRoots[0].Root
		};

		//LogRoots(namedRoots, root);

		var cap = new Cap(
			docUrl,
			snapshot.Screenshot,
			root
		);
		return cap;
	}





	/*private static TNod<CapNode>[] CaptureOtherRoots(this Web web)
	{
		var page = web.Page;
		var pageTarget = page.Target;

		bool IsTargetFromPage(Target t)
		{
			Target? curT = t;
			while (curT != null)
			{
				if (curT == pageTarget) return true;
				curT = curT.Opener;
			}
			return false;
		}

		return
			web.Browser.Targets()
				.Where(target => IsTargetFromPage(target) && target != pageTarget)
				.SelectToArray(target =>
					target.CreateCDPSessionAsync().Result
						.TakeSnap()
						.Single()
						.ToTree()
				);
	}*/

	private static SnapshotDoc[] TakeSnap(this CDPSession client)
	{
		var domSnap = client.DomSnapshot_CaptureSnapshot(
			computedStyles: Array.Empty<string>(),
			//computedStyles: new [] { "background-color" },
			includePaintOrder: false,
			includeDOMRects: true,
			includeBlendedBackgroundColors: false,
			includeTextColorOpacities: false
		);
		var docs = SnapshotConverter.Convert(domSnap);
		return docs;
	}

	private static TNod<CapNode> ToTree(this SnapshotDoc doc) =>
		doc.Root
			.Map(e => new CapNode(
				e.Index,
				e.NodeType,
				e.Name,
				(e.Text ?? string.Empty).Trim(),
				e.Attrs.SelectToArray(f => new CapAttr(f.Name, f.Value)),
				e.Bounds ?? R.Empty,
				e.IsClickable
			));



	private static Snapshot CaptureFull(this Web web, CapOpt opt)
	{
		var client = web.Page.Client;

		var domSnapshot = client.DomSnapshot_CaptureSnapshot(
			computedStyles: Array.Empty<string>(),
			//computedStyles: new [] { "background-color" },
			includePaintOrder: false,
			includeDOMRects: true,
			includeBlendedBackgroundColors: false,
			includeTextColorOpacities: false
		);

		var docs = SnapshotConverter.Convert(domSnapshot);

		var filteredDocs = docs
			.Where(doc => doc.DocumentUrl != Consts.InitialUrl)
			.Select(doc => doc.FilterDoc(opt))
			.ToArray();

		var screenshot = ScreenshotTaker.Take(web.Page, opt.ScreenCapType);

		var snapshot = new Snapshot(filteredDocs, screenshot);
		return snapshot;
	}

	private static SnapshotDoc FilterDoc(this SnapshotDoc doc, CapOpt opt) =>
		doc with
		{
			Root = doc.Root.FilterRoot(opt)
		};

	private static TNod<SnapshotNode> FilterRoot(this TNod<SnapshotNode> root, CapOpt opt)
	{
		var filteredRoot = root;

		if (opt.CaptureBodyOnly)
		{
			var bodyNod = filteredRoot.FirstOrDefault(e => e.V.Name == Consts.BodyName);
			if (bodyNod != null)
				filteredRoot = bodyNod;
		}

		static bool IsEmptyTextNod(TNod<SnapshotNode> nod)
		{
			if (nod.Children.Any()) return false;
			if (nod.V.NodeType != DomNodeType.Text) return false;
			if (nod.V.Text != null && nod.V.Text.Trim() != string.Empty) return false;
			return true;
		}

		filteredRoot = filteredRoot
			.FilterIf(opt.DiscardNodesWithoutRectangles, n => n.Bounds is not null && n.Bounds.Value.Width > 0 && n.Bounds.Value.Height > 0)
			.FilterIfN(opt.RemoveEmptyTextNodes, n => !IsEmptyTextNod(n))
			.Filter(n => !opt.NodeNamesToRemove.Contains(n.Name), filterOpt => filterOpt.AlwaysKeepRoot = true).Single();

		return filteredRoot;
	}


	private static TNod<T> FilterIf<T>(this TNod<T> root, bool enabled, Func<T, bool> predicate) => enabled switch
	{
		true => root.Filter(predicate, filterOpt => filterOpt.AlwaysKeepRoot = true).Single(),
		false => root
	};

	private static TNod<T> FilterIfN<T>(this TNod<T> root, bool enabled, Func<TNod<T>, bool> predicate) => enabled switch
	{
		true => root.FilterN(predicate, filterOpt => filterOpt.AlwaysKeepRoot = true).Single(),
		false => root
	};
}