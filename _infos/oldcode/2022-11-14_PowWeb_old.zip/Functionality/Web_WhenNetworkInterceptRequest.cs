﻿using System.Reactive.Linq;
using PowRxVar;
using PowWeb._Internal.ChromeDevApi.DFetch;
using PowWeb._Internal.ChromeDevApi.DFetch.Events;
using PowWeb._Internal.ChromeDevApi.DNetwork;
using PowWeb._Internal.ChromeDevApi.DNetwork.Enums;
using PowWeb._Internal.ChromeDevApi.Utils;

// ReSharper disable once CheckNamespace
namespace PowWeb;

public class FetchScript
{
	public string Url { get; }
	//public int? Index { get; }
	public string Body { get; set; }

	public FetchScript(string url/*, int? index*/, string body)
	{
		Url = url;
		//Index = index;
		Body = body;
	}
}

static class Web_WhenNetworkInterceptRequest
{
	public static void WhenNetworkInterceptRequest(this Web web)
	{
		var page = web.Page;
		var client = page.Client;
		client.Network_Enable();
		//client.Network
	}

	public static IObservable<FetchScript> WhenFetchInterceptRequest(this Web web)
	{
		var page = web.Page;
		var client = page.Client;
		client.Fetch_Enable();

		return Observable.Create<FetchScript>(subj =>
		{
			var d = new Disp();

			client.WhenEvent<AuthRequiredEvent>()
				.Subscribe(evt =>
				{
					var abc = 123;
				});

			client.WhenEvent<RequestPausedEvent>()
				.Subscribe(evt =>
				{
					void CallContinue()
					{
						client.Fetch_ContinueRequest(
							evt.RequestId,
							url: null,
							method: null,
							postData: null,
							headers: null,
							interceptResponse: true
						);
					}

					var isResponseStage = evt.ResponseErrorReason != null || evt.ResponseStatusCode != null;
					var isInterestingType = evt.ResourceType == ResourceType.Document || evt.ResourceType == ResourceType.Script;
					var isMediaType = evt.ResourceType == ResourceType.Media;

					if (isResponseStage && isMediaType)
					{
						var str = $"Found video: '{evt.Request.Url}'";
						var padStr = new string('=', str.Length + 4);
						Console.WriteLine();
						Console.WriteLine(padStr);
						Console.WriteLine($"* {str} *");
						Console.WriteLine(padStr);
						Console.WriteLine();

						Console.WriteLine("START GETTING VIDEO");
						var body = client.Fetch_GetResponseBody(evt.RequestId);
						Console.WriteLine("DONE GETTING VIDEO");

						CallContinue();

						return;
					}

					if (!isResponseStage || !isInterestingType)
					{
						CallContinue();
					}
					else
					{
						try
						{
							var body = client.Fetch_GetResponseBody(evt.RequestId);
							var script = new FetchScript(evt.Request.Url, body);
							subj.OnNext(script);
						}
						catch (Exception ex)
						{
							Console.WriteLine($"Exception calling Fetch_GetResponseBody: {ex.Message}");
						}
						finally
						{
							CallContinue();
						}
					}
				});

			return d;
		});
	}
}