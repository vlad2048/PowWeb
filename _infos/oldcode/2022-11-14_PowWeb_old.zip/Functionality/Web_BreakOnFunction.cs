﻿using PowWeb._Internal.ChromeDevApi.DDebugger;
using PowWeb._Internal.ChromeDevApi.DRuntime;
using PowWeb._Internal.ChromeDevApi.Utils;

// ReSharper disable once CheckNamespace
namespace PowWeb;

public static class Web_BreakOnFunction
{
	public static string BreakOnFunction(this Web web, string functionName, string? condition = null)
	{
		var client = web.Page.Client;
		var (res, ex) = client.Runtime_Evaluate(functionName);

		client.Debugger_Enable();

		var breakpointId = client.Debugger_SetBreakpointOnFunctionCall(res.ObjectId, condition);
		return breakpointId;
	}

	internal static IObservable<T> WhenEvent<T>(this Web web)
	{
		var client = web.Page.Client;
		return client.WhenEvent<T>();
	}
}