﻿using System.Reactive.Linq;
using DynamicData;
using PowRxVar;
using PowWeb._Internal;
using PowWeb._Internal.ChromeDevApi.DFetch.Events;
using PowWeb._Internal.ChromeDevApi.Utils;
using PowWeb._Internal.ExtWebOpt;
using PowWeb._Internal.Utils;
using PowWeb.Structs;
using PowWeb.Structs.Enums;
using PowWeb.Utils;
using PuppeteerSharp;

namespace PowWeb;


public class Web : IDisposable
{
	private readonly Disp d = new();
	public void Dispose() => d.Dispose();

	private readonly WebOpt opt;
	private readonly Page page;

	internal string CurrentUrl { get; set; }

	public Browser Browser { get; }

	public Page Page
	{
		get
		{
			PageUtils.CloseUnwantedTabsWhenAccessingPage(Browser, page, CurrentUrl);
			return page;
		}
	}

	internal Web(Browser browser, WebOpt opt)
	{
		Browser = browser.D(d);
		this.opt = opt;
		page = PageUtils.GetPageOnStartup(browser);
		CurrentUrl = Page.Url;
	}

	public static Web Get(Action<WebOpt>? optFun = null) => WebGetLogic.Get(optFun);

	public void Log(string str) => opt.Log(str);
	public void LogInline(string str) => opt.LogInline(str);
	public void BringToTop() => opt.BringToTop();

	private static string Truncate(string s, int lng) => (s.Length <= lng) switch
	{
		true => s,
		false => s[0..lng]
	};
}